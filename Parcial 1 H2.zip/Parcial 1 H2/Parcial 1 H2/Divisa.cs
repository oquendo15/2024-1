﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parcial_1_H2
{
    class Divisa
    {
        public int Valor { get; set; }
        public string DivisaInicial { get; set; }
        public string DivisaFinal { get; set; }

        public Divisa(int valor, string divisaInicial, string divisaFinal)
        {
            Valor = valor;
            DivisaInicial = divisaInicial;
            DivisaFinal = divisaFinal;
        }

    }
 }
