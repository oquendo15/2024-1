﻿
namespace Parcial_1_H2
{
    partial class FormParcial_1_H2
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblIngreso = new System.Windows.Forms.Label();
            this.lblDivisaInicial = new System.Windows.Forms.Label();
            this.lblDivisaFinal = new System.Windows.Forms.Label();
            this.lblResultado = new System.Windows.Forms.Label();
            this.rbtDivisaInicialDolar = new System.Windows.Forms.RadioButton();
            this.rbtDivisaInicialEuro = new System.Windows.Forms.RadioButton();
            this.rbtDivisaInicialPeso = new System.Windows.Forms.RadioButton();
            this.txtValorInicial = new System.Windows.Forms.TextBox();
            this.rbtDivisaFinalDólar = new System.Windows.Forms.RadioButton();
            this.rbtDivisaFinalEuro = new System.Windows.Forms.RadioButton();
            this.rbtDivisaFinalPeso = new System.Windows.Forms.RadioButton();
            this.txtRespuesta = new System.Windows.Forms.TextBox();
            this.btnConvertir = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblIngreso
            // 
            this.lblIngreso.AutoSize = true;
            this.lblIngreso.Location = new System.Drawing.Point(30, 23);
            this.lblIngreso.Name = "lblIngreso";
            this.lblIngreso.Size = new System.Drawing.Size(176, 13);
            this.lblIngreso.TabIndex = 0;
            this.lblIngreso.Text = "Ingrese la cantidad de dinero inicial:";
            // 
            // lblDivisaInicial
            // 
            this.lblDivisaInicial.AutoSize = true;
            this.lblDivisaInicial.Location = new System.Drawing.Point(30, 58);
            this.lblDivisaInicial.Name = "lblDivisaInicial";
            this.lblDivisaInicial.Size = new System.Drawing.Size(115, 13);
            this.lblDivisaInicial.TabIndex = 1;
            this.lblDivisaInicial.Text = "Ingrese la divisa inicial:";
            // 
            // lblDivisaFinal
            // 
            this.lblDivisaFinal.AutoSize = true;
            this.lblDivisaFinal.Location = new System.Drawing.Point(30, 148);
            this.lblDivisaFinal.Name = "lblDivisaFinal";
            this.lblDivisaFinal.Size = new System.Drawing.Size(203, 13);
            this.lblDivisaFinal.TabIndex = 2;
            this.lblDivisaFinal.Text = "Ingrese la divisa a la que desea convertir:";
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Font = new System.Drawing.Font("MV Boli", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.Location = new System.Drawing.Point(52, 346);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(146, 34);
            this.lblResultado.TabIndex = 3;
            this.lblResultado.Text = "Resultado:";
            // 
            // rbtDivisaInicialDolar
            // 
            this.rbtDivisaInicialDolar.AutoSize = true;
            this.rbtDivisaInicialDolar.Location = new System.Drawing.Point(151, 56);
            this.rbtDivisaInicialDolar.Name = "rbtDivisaInicialDolar";
            this.rbtDivisaInicialDolar.Size = new System.Drawing.Size(50, 17);
            this.rbtDivisaInicialDolar.TabIndex = 4;
            this.rbtDivisaInicialDolar.TabStop = true;
            this.rbtDivisaInicialDolar.Text = "Dólar";
            this.rbtDivisaInicialDolar.UseVisualStyleBackColor = true;
            // 
            // rbtDivisaInicialEuro
            // 
            this.rbtDivisaInicialEuro.AutoSize = true;
            this.rbtDivisaInicialEuro.Location = new System.Drawing.Point(151, 79);
            this.rbtDivisaInicialEuro.Name = "rbtDivisaInicialEuro";
            this.rbtDivisaInicialEuro.Size = new System.Drawing.Size(47, 17);
            this.rbtDivisaInicialEuro.TabIndex = 5;
            this.rbtDivisaInicialEuro.TabStop = true;
            this.rbtDivisaInicialEuro.Text = "Euro";
            this.rbtDivisaInicialEuro.UseVisualStyleBackColor = true;
            // 
            // rbtDivisaInicialPeso
            // 
            this.rbtDivisaInicialPeso.AutoSize = true;
            this.rbtDivisaInicialPeso.Location = new System.Drawing.Point(151, 102);
            this.rbtDivisaInicialPeso.Name = "rbtDivisaInicialPeso";
            this.rbtDivisaInicialPeso.Size = new System.Drawing.Size(49, 17);
            this.rbtDivisaInicialPeso.TabIndex = 6;
            this.rbtDivisaInicialPeso.TabStop = true;
            this.rbtDivisaInicialPeso.Text = "Peso";
            this.rbtDivisaInicialPeso.UseVisualStyleBackColor = true;
            // 
            // txtValorInicial
            // 
            this.txtValorInicial.Location = new System.Drawing.Point(216, 20);
            this.txtValorInicial.Name = "txtValorInicial";
            this.txtValorInicial.Size = new System.Drawing.Size(100, 20);
            this.txtValorInicial.TabIndex = 7;
            // 
            // rbtDivisaFinalDólar
            // 
            this.rbtDivisaFinalDólar.AutoSize = true;
            this.rbtDivisaFinalDólar.Location = new System.Drawing.Point(239, 148);
            this.rbtDivisaFinalDólar.Name = "rbtDivisaFinalDólar";
            this.rbtDivisaFinalDólar.Size = new System.Drawing.Size(50, 17);
            this.rbtDivisaFinalDólar.TabIndex = 8;
            this.rbtDivisaFinalDólar.TabStop = true;
            this.rbtDivisaFinalDólar.Text = "Dólar";
            this.rbtDivisaFinalDólar.UseVisualStyleBackColor = true;
            // 
            // rbtDivisaFinalEuro
            // 
            this.rbtDivisaFinalEuro.AutoSize = true;
            this.rbtDivisaFinalEuro.Location = new System.Drawing.Point(239, 171);
            this.rbtDivisaFinalEuro.Name = "rbtDivisaFinalEuro";
            this.rbtDivisaFinalEuro.Size = new System.Drawing.Size(47, 17);
            this.rbtDivisaFinalEuro.TabIndex = 9;
            this.rbtDivisaFinalEuro.TabStop = true;
            this.rbtDivisaFinalEuro.Text = "Euro";
            this.rbtDivisaFinalEuro.UseVisualStyleBackColor = true;
            // 
            // rbtDivisaFinalPeso
            // 
            this.rbtDivisaFinalPeso.AutoSize = true;
            this.rbtDivisaFinalPeso.Location = new System.Drawing.Point(239, 194);
            this.rbtDivisaFinalPeso.Name = "rbtDivisaFinalPeso";
            this.rbtDivisaFinalPeso.Size = new System.Drawing.Size(49, 17);
            this.rbtDivisaFinalPeso.TabIndex = 10;
            this.rbtDivisaFinalPeso.TabStop = true;
            this.rbtDivisaFinalPeso.Text = "Peso";
            this.rbtDivisaFinalPeso.UseVisualStyleBackColor = true;
            // 
            // txtRespuesta
            // 
            this.txtRespuesta.Location = new System.Drawing.Point(216, 359);
            this.txtRespuesta.Name = "txtRespuesta";
            this.txtRespuesta.Size = new System.Drawing.Size(100, 20);
            this.txtRespuesta.TabIndex = 11;
            // 
            // btnConvertir
            // 
            this.btnConvertir.Location = new System.Drawing.Point(216, 258);
            this.btnConvertir.Name = "btnConvertir";
            this.btnConvertir.Size = new System.Drawing.Size(100, 52);
            this.btnConvertir.TabIndex = 12;
            this.btnConvertir.Text = "Convertir";
            this.btnConvertir.UseVisualStyleBackColor = true;
            this.btnConvertir.Click += new System.EventHandler(this.btnConvertir_Click);
            // 
            // Inicio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnConvertir);
            this.Controls.Add(this.txtRespuesta);
            this.Controls.Add(this.rbtDivisaFinalPeso);
            this.Controls.Add(this.rbtDivisaFinalEuro);
            this.Controls.Add(this.rbtDivisaFinalDólar);
            this.Controls.Add(this.txtValorInicial);
            this.Controls.Add(this.rbtDivisaInicialPeso);
            this.Controls.Add(this.rbtDivisaInicialEuro);
            this.Controls.Add(this.rbtDivisaInicialDolar);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.lblDivisaFinal);
            this.Controls.Add(this.lblDivisaInicial);
            this.Controls.Add(this.lblIngreso);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Inicio";
            this.Text = "CALCULADORA DE CONVERSIÓN";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblIngreso;
        private System.Windows.Forms.Label lblDivisaInicial;
        private System.Windows.Forms.Label lblDivisaFinal;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.RadioButton rbtDivisaInicialDolar;
        private System.Windows.Forms.RadioButton rbtDivisaInicialEuro;
        private System.Windows.Forms.RadioButton rbtDivisaInicialPeso;
        private System.Windows.Forms.TextBox txtValorInicial;
        private System.Windows.Forms.RadioButton rbtDivisaFinalDólar;
        private System.Windows.Forms.RadioButton rbtDivisaFinalEuro;
        private System.Windows.Forms.RadioButton rbtDivisaFinalPeso;
        private System.Windows.Forms.TextBox txtRespuesta;
        private System.Windows.Forms.Button btnConvertir;
    }
}

